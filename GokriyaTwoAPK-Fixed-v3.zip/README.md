# Gokriya Two APK

GitHub-ready source for two separate Android APKs:

- `Franchise` APK — franchise ordering app
- `Plant` APK — plant order-management app

The GitHub Actions workflow builds both APKs in the cloud. No laptop is required for the build.

## Build
Open GitHub → Actions → Build Gokriya APKs → Run workflow.

After the workflow completes, download:
- `Gokriya-Franchise-APK`
- `Gokriya-Plant-APK`

## Important
The current app uses the Supabase publishable key in the client, which is appropriate for client-side use when Supabase RLS/policies are configured correctly. Never put a Supabase service-role/secret key into an APK.

Payment is still demo payment in this prototype. Real PhonePe/UPI payment requires secure server-side payment verification before production use.
