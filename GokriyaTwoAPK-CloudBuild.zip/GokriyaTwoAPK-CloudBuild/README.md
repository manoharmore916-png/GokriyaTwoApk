# Gokriya Two APK – Cloud Build Source

This package wraps the working Supabase-connected Gokriya HTML app in Capacitor so Android APKs can be built in the cloud.

## Apps
- Franchise APK: `franchise/index.html` — Franchise-only login (demo PIN 1234)
- Plant APK: `plant/index.html` — Plant-only login (demo PIN 9999)

## Important
The Supabase publishable key is intended for client use. Never put a Supabase service-role/secret key in the APK.

Payment is still DEMO payment in this prototype. Real PhonePe/UPI payment needs a secure backend verification flow before production use.

## Cloud build
Use a GitHub repository and GitHub Actions. The workflow in `.github/workflows/android.yml` builds both debug APKs without a laptop.
